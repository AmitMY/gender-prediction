------------------------------------------------------------------------------------------
TwiSty Corpus
------------------------------------------------------------------------------------------

Creator(s):
	Ben Verhoeven (1), Walter Daelemans (1), Barbara Plank (2)

	(1) CLiPS Research Center, University of Antwerp, Belgium
	(2) University of Groningen, The Netherlands

Version: 2016-03
Languages: Dutch, Italian, German, French, Spanish, Portuguese

This dataset is available at http://www.clips.uantwerpen.be/datasets
Previous versions of the dataset remain available from the authors via e-mail request.

License:
	This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International 
	License. To view a copy of this license, visit 
	http://creativecommons.org/licenses/by-sa/4.0/

Description:
	TwiSty is a corpus developed for research in author profiling. It contains 
	personality (MBTI) and gender annotations for a total of 18,168 authors spanning six 
	languages. We distribute the Twitter ids of these authors as well as the ids of their 
	available tweets at the time of corpus development. The tweets have undergone language 
	identification and can be found in a 'confirmed' (as belonging to the language in which 
	the author is situated) and 'other' category (other tweets of this author, 
	automatically identified to be in other languages).

If you use this dataset in your research, make sure to cite the following paper:

	Verhoeven, B., Daelemans, W., & Plank, B. (2016). TwiSty: A multilingual Twitter 
	Stylometry Corpus for gender and personality profiling. In: Proceedings of the 10th 
	International Conference on Language Resources and Evaluation (LREC 2016). Portorož, 
	Slovenia. European Language Resources Association (ELRA). 1632-1637.
	(Full paper at http://www.clips.uantwerpen.be/bibliography/twisty-corpus)

Acknowledgement:
	We would like to express our gratitude to Guy De Pauw and Tom De Smedt (University
	of Antwerp) for technical support.
	The development of this corpus was supported by a PhD grant of FWO - Research 
	Foundation Flanders for the first author. Part of this research was carried out in 
	the framework of the AMiCA (IWT SBO-project 120007) project, funded by the Flemish 
	government agency for Innovation by Science and Technology (IWT).


------------------------------------------------------------------------------------------
Corpus Structure
------------------------------------------------------------------------------------------

The corpus consists of json files, one for each of the six languages: Dutch, Italian,
German, French, Portuguese, Spanish.

Each json file contains Twitter profiles with their self-assessed MBTI personality type 
and annotated gender.
Each profile has two lists of tweet ids: one of which the language was confirmed to belong 
to this corpus, the other contains all the other tweets we were able to mine.

Each json file is structured as follows:

{user_id1 : 	
		{`user_id': user_id1,
		`mbti': `ESTP',
		`gender':'M',
		`confirmed_tweet_ids': [tweet_id1, tweet_id2, tweet_id4],
		`other_tweet_ids': [tweet_id3, tweet_id5]
		}
}

------------------------------------------------------------------------------------------
Corpus Statistics
------------------------------------------------------------------------------------------

See the technical report:
	
	Verhoeven, B., Daelemans, W., & Plank, B. (2016) Creating TwiSty: Corpus Development
	and Statistics. CLiPS Technical Report Series (CTRS), 6.
	(Full paper at http://www.clips.uantwerpen.be/ctrs/creating-twisty-corpus-development-and-statistics)
